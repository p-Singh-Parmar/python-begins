# coding: utf8
from __future__ import unicode_literals

from ...extra.search import MaxViolation


def test_init_violn():
    MaxViolation()
